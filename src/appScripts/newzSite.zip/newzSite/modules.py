
# find the article info
def get_article(headlineIn):
    headline = headlineIn
    storyUrl = "https://www.cnbc.com/2020/12/28/house-votes-on-2000-stimulus-checks-after-trump-signs-relief-bill.html"
    relatedArticles = [
        "https://www.cnbc.com/2020/12/28/house-votes-on-2000-stimulus-checks-after-trump-signs-relief-bill.html",
        "https://www.thedailybeast.com/kim-yo-jong-is-ready-to-become-the-first-woman-dictator-in-modern-history"
    ]
    bias = "center"
    sentiment = 1
    coverage = "010"
    return headline, storyUrl, relatedArticles, bias, sentiment, coverage
