from modules import get_article
from flask import Flask, render_template, redirect, url_for
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)

# Flask-WTF requires an encryption key - the string can be anything
app.config['SECRET_KEY'] = 'C2HWGVoMGfNTBsrYQg8EcMrdTimkZfAb'

# Flask-Bootstrap requires this line
Bootstrap(app)

# with Flask-WTF, each web form is represented by a class
# "HeadLineForm" can change; "(FlaskForm)" cannot
# see the route for "/" and "index.html" to see how this is used


class HeadLineForm(FlaskForm):
    headlineIn = StringField('Enter Headline', validators=[DataRequired()])
    submit = SubmitField('Submit')


# all Flask routes below

@app.route('/', methods=['GET', 'POST'])
def index():
    # you must tell the variable 'form' what you named the class, above
    # 'form' is the variable name used in this template: index.html
    form = HeadLineForm()
    name = ""
    if form.validate_on_submit():
        headlineIn = form.headlineIn.data
        return redirect(url_for('article', headlineIn=headlineIn))
    else:
        message = "This is a message"
    return render_template('index.html', form=form, message=message)


@app.route('/article/<headlineIn>')
def article(headlineIn):
    # run function to get article data based on the name in the path
    headline, storyUrl, relatedArticles, bias, sentiment, coverage = get_article(
        headlineIn)
    photo = ""
    if headlineIn == "Unknown":
        # redirect the browser to the error template
        return render_template('404.html'), 404
    else:
        # pass all the data for the selected actor to the template
        return render_template("newzOut.html",
                               headline=headline,
                               storyUrl=storyUrl,
                               bias=bias,
                               sentiment=sentiment,
                               coverage=coverage,
                               relatedArticles=relatedArticles
                               )


@app.route("/newz")
def home():
    return render_template("newzOut.html",
                           headline=headline,
                           storyUrl=storyUrl,
                           bias=bias,
                           sentiment=sentiment,
                           coverage=coverage,
                           relatedArticles=relatedArticles
                           )


@app.route("/bias")
def biasSource():
    return render_template("bias.html", content="Testing")


@app.route("/design")
def design():
    return render_template("design.html", content="Testing")

# 2 routes to handle errors - they have templates too


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500


if __name__ == "__main__":
    app.run(debug=True)
