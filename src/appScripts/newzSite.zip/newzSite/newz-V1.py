from flask import Flask, redirect, url_for, render_template

app = Flask(__name__)

headline = "House to vote on $2,000 stimulus checks after Trump signs Covid relief and funding bill"
storyUrl = "https://www.cnbc.com/2020/12/28/house-votes-on-2000-stimulus-checks-after-trump-signs-relief-bill.html"
relatedArticles = [
    "https://www.cnbc.com/2020/12/28/house-votes-on-2000-stimulus-checks-after-trump-signs-relief-bill.html",
    "https://www.thedailybeast.com/kim-yo-jong-is-ready-to-become-the-first-woman-dictator-in-modern-history"
]
bias = "center"
sentiment = 1
coverage = "010"

@app.route("/newz")
def newz():
    return render_template("newzOut.html",
                           headline=headline,
                           storyUrl=storyUrl,
                           bias=bias,
                           sentiment=sentiment,
                           coverage=coverage,
                           relatedArticles=relatedArticles
                           )

@app.route("/bias")
def biasSource():
    return render_template("bias.html", content="Testing" )

@app.route("/design")
def design():
    return render_template("design.html", content="Testing" )

if __name__ == "__main__":
    app.run(debug=True)
